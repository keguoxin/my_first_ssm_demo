package com.nuonuode.service.impl;




import com.nuonuode.beans.Student;
import com.nuonuode.dao.StudentMapper;
import com.nuonuode.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("studentService")
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentMapper dao;

    public void setDao(StudentMapper dao) {
        this.dao = dao;
    }

    @Transactional
    public void addStudent(Student student) {
        dao.insertStudent(student);
    }

}
