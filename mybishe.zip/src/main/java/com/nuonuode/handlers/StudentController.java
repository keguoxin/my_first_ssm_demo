package com.nuonuode.handlers;

import com.nuonuode.beans.Student;
import com.nuonuode.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;

@Controller
@RequestMapping("/user")
public class StudentController {

    @Autowired
    private StudentService service;

    public void setService(StudentService service) {
        this.service = service;
    }
    /*  ${pageContext.request.contextPath}/user/register.do 通过@RequestMapping去匹配
    * */
    @RequestMapping("/register")
    public String doRegister(String name, int age, HttpServletRequest request) {
        Student student = new Student(name, age);
        service.addStudent(student);
        request.setAttribute("studentName", name);
        //return "/welcome.jsp";//因为我在springmvc中配置好格式了
        return "welcome";
    }
}
