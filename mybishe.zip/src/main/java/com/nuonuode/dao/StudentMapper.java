package com.nuonuode.dao;

import com.nuonuode.beans.Student;

public interface StudentMapper {
    void insertStudent(Student student);
}
