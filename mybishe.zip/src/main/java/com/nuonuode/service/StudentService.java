package com.nuonuode.service;

import com.nuonuode.beans.Student;

public interface StudentService {
    void addStudent(Student student);
}
